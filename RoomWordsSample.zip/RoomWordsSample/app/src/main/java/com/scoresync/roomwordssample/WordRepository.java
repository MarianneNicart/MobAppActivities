package com.scoresync.roomwordssample;


import android.app.Application;

import androidx.lifecycle.LiveData;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


public class WordRepository {

    private WordDao mWordDao;
    private LiveData<List<Word>> mAllWords;

    // A thread pool for background tasks
    private static final ExecutorService databaseWriteExecutor =
            Executors.newFixedThreadPool(4);

    // Constructor
    public WordRepository(Application application) {
        WordRoomDatabase db = WordRoomDatabase.getDatabase(application);
        mWordDao = db.wordDao();
        mAllWords = mWordDao.getAllWords(); // this is LiveData
    }

    // Expose LiveData
    public LiveData<List<Word>> getAllWords() {
        return mAllWords;
    }

    // Insert a word (in background)
    public void insert(final Word word) {
        databaseWriteExecutor.execute(() -> mWordDao.insert(word));
    }
}
