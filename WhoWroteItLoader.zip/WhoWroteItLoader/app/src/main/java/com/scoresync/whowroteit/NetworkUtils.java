package com.scoresync.whowroteit;

public class NetworkUtils {
    static String getBookInfo(String queryString) {
        // Build URL using Uri.Builder
        // Use HttpURLConnection + InputStream + BufferedReader
        // Return JSON response as string
    }
}
